package io.altar.jseproject.services;

public class EntityService {

}
