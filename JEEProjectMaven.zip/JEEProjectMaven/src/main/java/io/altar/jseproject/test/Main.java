package io.altar.jseproject.test;

import io.altar.jseproject.textinterface.TextInterfaceStateMachine;

public class Main {
    public static void main(String[] args) {
        TextInterfaceStateMachine sm = new TextInterfaceStateMachine();
		sm.start();
    }
}