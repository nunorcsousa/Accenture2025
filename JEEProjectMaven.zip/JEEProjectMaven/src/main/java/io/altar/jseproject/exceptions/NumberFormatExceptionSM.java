package io.altar.jseproject.exceptions;

public class NumberFormatExceptionSM extends NumberFormatException {

    private static final long serialVersionUID = 1149251039409861914L;

    public NumberFormatExceptionSM(String msg){
        super(msg);
    }

}
